# Discord Giveaway Join Bot
This bot will automatically look for giveaways and join them.

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Kuuhhl/Discord-Giveaway-Join-Bot)

# How to get an authentification-token
To run the bot, you will have to provide your authentification token. 
To get one:
1. open Discord in your browser
2. press F12 
3. select the 'Network'-tab.
4. select a different server/channel.

You should find a log that says `messages?limit=50` .
Click it and copy the authentification code from the request headers.

**Image guide:**

![Image guide](https://i.imgur.com/xKHVrfZ.png)
